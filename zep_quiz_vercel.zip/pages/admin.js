import { useState, useEffect } from "react";
export default function Admin(){
  const [pwd,setPwd]=useState('');
  const [logged,setLogged]=useState(false);
  const [tests,setTests]=useState([]);
  const [name,setName]=useState('');
  const [seconds,setSeconds]=useState(12);
  const [questionsText,setQuestionsText]=useState('[{"q":"Contoh?","options":["A","B","C","D"],"correct":0}]');

  useEffect(()=>{ if(logged) loadTests(); },[logged]);

  async function login(){
    const res = await fetch('/api/admin_login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pwd})});
    const j = await res.json();
    if(j.ok) setLogged(true); else alert('Password salah');
  }
  async function loadTests(){
    const res = await fetch('/api/get_tests');
    const j = await res.json();
    if(j.ok) setTests(j.tests);
  }
  function genCode(len=6){ const chars="ABCDEFGHJKMNPQRSTUVWXYZ23456789"; let s=''; for(let i=0;i<len;i++) s+=chars[Math.floor(Math.random()*chars.length)]; return s; }

  async function createTest(){
    let qs;
    try{ qs = JSON.parse(questionsText); } catch(e){ return alert('Soal harus JSON array'); }
    const code = genCode();
    const res = await fetch('/api/create_test',{method:'POST',headers:{'Content-Type':'application/json','x-admin-password':process.env.NEXT_PUBLIC_ADMIN_PASSWORD || ''},body:JSON.stringify({code,name,seconds_per_question:Number(seconds),questions:qs})});
    const j = await res.json();
    if(j.ok){ alert('Test dibuat: '+code); loadTests(); } else alert('Gagal: '+(j.msg||'')); 
  }

  async function viewSubs(code){
    const res = await fetch('/api/get_scores?code='+encodeURIComponent(code));
    const j = await res.json();
    if(!j.ok) return alert('Gagal ambil');
    alert(j.scores.map(s=>`${s.student_name} — ${s.score} — ${new Date(s.created_at).toLocaleString()}`).join('\n')||'Tidak ada');
  }

  return (
    <div className="container">
      {!logged ? (
        <div>
          <h2>Admin Login</h2>
          <input placeholder="Password admin" value={pwd} onChange={e=>setPwd(e.target.value)} />
          <div style={{marginTop:8}}><button onClick={login}>Login</button></div>
        </div>
      ) : (
        <div>
          <h2>Admin Dashboard</h2>
          <div style={{marginBottom:12}}>
            <h3>Buat Test Baru</h3>
            <input placeholder="Nama Test" value={name} onChange={e=>setName(e.target.value)} />
            <input placeholder="Detik per soal" value={seconds} onChange={e=>setSeconds(e.target.value)} />
            <textarea rows={6} style={{width:'100%'}} value={questionsText} onChange={e=>setQuestionsText(e.target.value)} />
            <div style={{marginTop:8}}><button onClick={createTest}>Buat Test</button></div>
          </div>
          <div>
            <h3>Daftar Tests</h3>
            <table border="1" cellPadding="6" style={{width:'100%',borderCollapse:'collapse'}}>
              <thead><tr><th>Code</th><th>Nama</th><th>Soal</th><th>Detik</th><th>Active</th><th>Aksi</th></tr></thead>
              <tbody>
                {tests.map(t=>(
                  <tr key={t.code}>
                    <td>{t.code}</td>
                    <td>{t.name}</td>
                    <td>{t.questions.length}</td>
                    <td>{t.seconds_per_question}</td>
                    <td>{t.active? 'YES':'NO'}</td>
                    <td><button onClick={()=>viewSubs(t.code)}>Lihat Nilai</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
