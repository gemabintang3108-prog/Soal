import { useState, useEffect, useRef } from "react";
export default function Home(){
  const [stage,setStage]=useState('join');
  const [name,setName]=useState('');
  const [code,setCode]=useState('');
  const [test,setTest]=useState(null);
  const [indexQ,setIndexQ]=useState(0);
  const [score,setScore]=useState(0);
  const [secondsLeft,setSecondsLeft]=useState(0);
  const timerRef=useRef(null);

  async function join(){
    if(!name.trim()||!code.trim()) return alert('Isi nama & kode');
    const res=await fetch(`/api/check_code?code=${encodeURIComponent(code.trim())}`);
    const j=await res.json();
    if(!j.ok) return alert(j.msg||'Kode tidak valid');
    setTest(j.test);
    setIndexQ(0); setScore(0);
    setSecondsLeft(j.test.seconds_per_question);
    setStage('play');
  }

  useEffect(()=>{
    if(stage!=='play'){ if(timerRef.current){clearInterval(timerRef.current);timerRef.current=null;} return;}
    setSecondsLeft(test.seconds_per_question);
    timerRef.current = setInterval(() => {
      setSecondsLeft(s=>{
        if(s<=1){
          clearInterval(timerRef.current); timerRef.current=null;
          nextQuestion(null); return 0;
        }
        return s-1;
      });
    },1000);
    return ()=>{ if(timerRef.current) clearInterval(timerRef.current); }
  },[stage,indexQ,test]);

  function pickOption(optIndex){
    if(!test) return;
    const correct = test.questions[indexQ].correct;
    if(optIndex===correct) setScore(s=>s+1);
    if(timerRef.current){ clearInterval(timerRef.current); timerRef.current=null; }
    nextQuestion(optIndex);
  }

  function nextQuestion(){
    setTimeout(()=>{
      if(indexQ+1>=test.questions.length) finish();
      else { setIndexQ(i=>i+1); setSecondsLeft(test.seconds_per_question); }
    },400);
  }

  async function finish(){
    setStage('done');
    await fetch('/api/submit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name.trim(),code:code.trim(),score})});
  }

  if(stage==='join') return (
    <div className="container">
      <h2>ZEP Quiz — Murid</h2>
      <div>
        <input placeholder="Nama" value={name} onChange={e=>setName(e.target.value)} />
      </div>
      <div style={{marginTop:8}}>
        <input placeholder="Kode Ujian" value={code} onChange={e=>setCode(e.target.value)} />
      </div>
      <div style={{marginTop:12}}><button onClick={join}>Mulai</button></div>
      <p style={{color:'#666'}}>Murid hanya boleh mengerjakan 1x per kode.</p>
    </div>
  );

  if(stage==='play'&&test) {
    const q = test.questions[indexQ];
    return (
      <div className="container">
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div><strong>{test.name}</strong> — Soal {indexQ+1}/{test.questions.length}</div>
          <div>Waktu: {secondsLeft}s</div>
        </div>
        <div style={{marginTop:12,padding:16,background:'#fff',borderRadius:8}}>
          <div style={{fontSize:18,marginBottom:12}}>{q.q}</div>
          <div>{q.options.map((opt,i)=>(
            <div key={i} style={{margin:'8px 0'}}><button onClick={()=>pickOption(i)}>{opt}</button></div>
          ))}</div>
        </div>
      </div>
    );
  }

  if(stage==='done') return (
    <div className="container">
      <h2>Terima kasih!</h2>
      <p>Nama: <b>{name}</b></p>
      <p>Skor: <b>{score}/{test.questions.length}</b></p>
      <p>Nilai sudah terkirim ke admin.</p>
      <div><button onClick={()=>window.location.href='/'}>Kembali</button></div>
    </div>
  );

  return <div className="container">Loading...</div>;
}
