# ZEP Quiz — Vercel + Supabase (Ready)

This is a minimal Next.js project for ZEP Quiz (student + admin) designed to deploy on Vercel and use Supabase as database.

## Quick steps
1. Create Supabase project. Run SQL (see below) to create `tests` and `submissions`.
2. Set Vercel environment variables:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
   - SUPABASE_SERVICE_ROLE_KEY
   - ADMIN_PASSWORD
3. Deploy to Vercel (import repo). After deploy, open `/admin` to create tests.

## Supabase SQL
Run the SQL below in Supabase SQL editor:

```sql
create extension if not exists "pgcrypto";

create table tests (
  id uuid default gen_random_uuid() primary key,
  code text unique not null,
  name text,
  seconds_per_question int not null default 12,
  questions jsonb not null,
  active boolean not null default true,
  created_at timestamptz default now()
);

create table submissions (
  id uuid default gen_random_uuid() primary key,
  test_code text not null references tests(code) on delete cascade,
  student_name text not null,
  score int not null,
  metadata jsonb,
  created_at timestamptz default now()
);

create unique index on submissions (test_code, student_name);
```
